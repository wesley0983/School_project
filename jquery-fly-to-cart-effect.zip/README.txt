A Pen created at CodePen.io. You can find this one at https://codepen.io/wesley0983/pen/mazMbe.

 Add to cart fly effect with jQuery.
[Available on github](https://github.com/ElmahdiMahmoud/fly-to-cart-effect.)

#### Plugin is now available checkout the following links for more details:

> Plugin [Details demo](http://codepen.io/ElmahdiMahmoud/details/dshgJ)

or

> Plugin [Full demo](http://codepen.io/ElmahdiMahmoud/full/dshgJ)

 [Download plugin as zip](https://dl.dropboxusercontent.com/u/70204595/plugins/flyto/src/flyto.zip)